## ODM-seq analysis for Langstein-Skora et al

This repository contains the code to analyse the effects of Abf1 WT, Abf1 variants and Abf1 ablation on chromatin structure.
Uploded is the source code of the snakemake pipeline for processing sorted and aligned bam files of ODM-seq data as well as the R code for plotting the pipeline output.
