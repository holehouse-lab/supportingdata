source(".RProfile")
source("R/plot_fun.R")
library("data.table")
library("ggVennDiagram")

origins <- readRDS(paste0(external, "abf1_origin_files.rds"))

nuc <- origins %>%
  dplyr::mutate(source = dplyr::case_when(
    origin %in% c("Pugh-Chip-exo", "Hahn-ChEC", "Henikoff-ChEC", "SLiM-ChIP") ~ "in vivo",
    origin %in% c("Macisaac", "pachkov", "jaspar", "badis", "kubik") ~ "pwm")) %>%
  dplyr::filter(source %in% c("in vivo", "pwm")) %>%
  dplyr::select(chr, poi, source) %>%
  distinct()

ol <- nuc %>%
  dplyr::mutate(ext_start = poi - 75,
                ext_end = poi + 75) %>%
  dplyr::rename(value = poi,
                origin = source) %>%
  dplyr::select(chr, ext_start, ext_end, value, origin) %>%
  dplyr::filter(value > 0,
                ext_start < ext_end,
                ext_start > 0) %>%
  dplyr::mutate(ext_start = as.integer(ext_start),
                ext_end = as.integer(ext_end)) %>%
  dplyr::arrange(chr, value) %>%
  data.table() %>%
  setkey(., chr, ext_start, ext_end)

  thin <- ol %>%
  dplyr::select(chr, value) %>%
  dplyr::rename(poi = value) %>%
  distinct() %>%
  dplyr::group_by(chr) %>%
  dplyr::arrange(chr, poi) %>%
  dplyr::mutate(difference = poi - dplyr::lag(poi)) %>%
  dplyr::filter(is.na(difference) | difference >= 20) %>%
  dplyr::mutate(end = as.integer(poi + 1)) %>%
  dplyr::filter(poi > 0) %>%
  dplyr::select(-difference) %>%
  tibble::rowid_to_column("track") %>%
  data.table() %>%
  setkey(., chr, poi, end)

resp <- data.table::foverlaps(y = thin,
                              x = ol,
                              by.y = c("chr", "poi", "end"),
                              by.x = c("chr", "ext_start", "ext_end"))

venn_list <- resp %>%
  split(., .$origin) %>%
  purrr::map(., ~pull(.x, track))

pdf(paste0(plotdir, "pwm_vs_gsm_venn.pdf"), height = 10, width = 10)
g <- ggVennDiagram(venn_list, label = "count") +
  ggtitle("") +
  scale_fill_gradient2(low = "white", high = "white", mid = "white") +
  theme(legend.position = "none")
print(g)
dev.off()

