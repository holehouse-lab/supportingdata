source(".RProfile")
source("R/plot_fun.R")
library("data.table")

view = 1000
data <- fread(paste0(datasets, "41586_2025_8916_MOESM4_ESM/ref_all-Table 1.tsv"),sep = "\t")

point1 <- fread(paste0(datasets, "41586_2025_8916_MOESM5_ESM 3/Table-S3a-Table 1.tsv"),sep = "\t") %>%
  dplyr::select(gene_id, ABF1) %>%
  dplyr::filter(ABF1 == 1)

point2 <- fread(paste0(datasets, "41586_2025_8916_MOESM5_ESM 3/Table-S3c-Table 1.tsv"),sep = "\t") %>%
  dplyr::select(V1, ABF1) %>%
  dplyr::filter(ABF1 != "") %>%
  dplyr::rename(gene_id = V1,
                expression = ABF1)
points <- dplyr::full_join(point1, point2)

data %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(ext_start = poi - view,
                ext_end = poi + view,
                factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  drop_na(poi) %>%
  saveRDS(., paste0(external, "Hahn_plus_one_data.table.rds"))

both <- points %>%
  dplyr::filter(!is.na(ABF1) & !is.na(expression))
data %>%
  dplyr::filter(gene_id %in% both$gene_id) %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  tidyr::drop_na(poi) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(ext_start = poi - view,
                ext_end = poi + view,
                factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  drop_na(poi) %>%
  saveRDS(., paste0(external, "Hahn_bound_and_resp_data.table.rds"))

bound_only <- points %>%
  dplyr::filter(!is.na(ABF1) & is.na(expression))

data %>%
  dplyr::filter(gene_id %in% bound_only$gene_id) %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  tidyr::drop_na(poi) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(ext_start = poi - view,
                ext_end = poi + view,
                factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  saveRDS(., paste0(external, "Hahn_bound_only_data.table.rds"))

resp_only <- points %>%
  dplyr::filter(is.na(ABF1) & !is.na(expression))

data %>%
  dplyr::filter(gene_id %in% resp_only$gene_id) %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  tidyr::drop_na(poi) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(ext_start = poi - view,
                ext_end = poi + view,
                factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  saveRDS(., paste0(external, "Hahn_resp_only_data.table.rds"))

all_resp <- points %>%
  dplyr::filter(!is.na(expression))

data %>%
  dplyr::filter(gene_id %in% all_resp$gene_id) %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  tidyr::drop_na(poi) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(ext_start = poi - view,
                ext_end = poi + view,
                factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  saveRDS(., paste0(external, "Hahn_all_resp_data.table.rds"))

