source(".RProfile")
source("R/plot_fun.R")
library("data.table")
library("ggVennDiagram")

point <- readRDS(paste0(sshfs, snakemake_TFA, "Abf1_plus_ones/rds/20240129_corrected.rds"))

data <- point %>%
  dplyr::select(chr, pos, strand, occ, cat) %>%
  dplyr::group_by(chr, pos, strand, cat) %>%
  dplyr::summarise(mean = mean(occ, na.rm = T)) %>%
  dplyr::ungroup() %>%
  dplyr::rename(chrom = chr, end = pos, value = mean) %>%
  dplyr::mutate(start = end -1) %>%
  dplyr::select(chrom, start, end, value, cat) %>%
  split(.$cat) %>%
  purrr::map(., ~select(.x, -cat))

data %>%
  purrr::map2(.x = ., .y = names(.), ~write_delim(.x, paste0(datadir, .y, "_mean_track.bedgraph"),
                                                  delim = "\t", col_names = F))
              
              