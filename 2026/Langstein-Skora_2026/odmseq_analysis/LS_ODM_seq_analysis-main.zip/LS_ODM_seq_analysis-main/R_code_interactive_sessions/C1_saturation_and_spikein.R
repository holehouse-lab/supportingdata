source(".RProfile")

prep = "Abf1_sites"
id = "20240129"
data <- readRDS(paste0(sshfs, snakemake_TFA, prep, "/methylation/", id, "_subset_methylation.rds"))

shapes = c("240 min, replicate 1" = 16,
           "180 min, replicate 1" = 1,
           "240 min, replicate 2" = 17,
           "180 min, replicate 2" = 2)

levs = c("no Abf1", "Local Shuffle 12", "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045", "altered aromatic patterning", "Gal4 shuffle", "Fus Gal4 motif", "WT Abf1")

df <- data %>%
  dplyr::rename(barcode = sample) %>%
  tidyr::separate(barcode, sep = "_", into = c("sample", "time")) %>%
  dplyr::mutate(cat = dplyr::case_when(
    sample %in% c("ASK460", "ASK461") ~ "no Abf1",
    sample %in% c("ASK459", "ASK455") ~ "WT Abf1",
    sample %in% c("ASK454", "ASK458") ~ "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045",
    sample %in% c("ASK470", "ASK471") ~ "altered aromatic patterning",
    sample %in% c("ASK468", "ASK469") ~ "Local Shuffle 12",
    sample %in% c("ASKGS1", "ASKGS2") ~ "Gal4 shuffle",
    sample %in% c("ASKFG1", "ASKFG2") ~ "Fus Gal4 motif")) %>%
  dplyr::mutate(rep = dplyr::case_when(
    sample %in% c("ASK460", "ASK459", "ASK454", "ASK470", "ASK468", "ASKGS1", "ASKFG1") ~ "replicate 1",
    sample %in% c("ASK461", "ASK455", "ASK458", "ASK471", "ASK469", "ASKGS2", "ASKFG2") ~ "replicate 2")) %>%
  dplyr::mutate(group = paste0(time, " min, ", rep)) %>%
  dplyr::filter(!is.na(rep))%>%
  dplyr::mutate(cat = factor(cat, levels = levs))

tsv <- df %>%
  dplyr::select(cat, group, chr, count) %>%
  dplyr::filter(chr %in% c("genome", "puc19_ftz", "pFMP233")) %>%
  pivot_wider(names_from = chr, values_from = count)

write_delim(tsv, paste0(datadir, prep, "_spike_in_counts.tsv"), delim = "\t")

pdf(paste0(plotdir, prep, "_spikein.pdf"), height = 4.5, width = 5)
lvs = c( "no Abf1 replicate 1",
         "no Abf1 replicate 2",
         "Local Shuffle 12 replicate 1",
         "Local Shuffle 12 replicate 2",
         "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045 replicate 1",
         "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045 replicate 2",
         "altered aromatic patterning replicate 1",
         "altered aromatic patterning replicate 2",
         "Gal4 shuffle replicate 1",
         "Gal4 shuffle replicate 2",
         "Fus Gal4 motif replicate 1",
         "Fus Gal4 motif replicate 2" ,
         "WT Abf1 replicate 1",
         "WT Abf1 replicate 2")

ggplot(df %>% dplyr::filter(chr == "pFMP233", time == "240") %>%
         dplyr::mutate(label = factor(paste(cat, rep), levels = lvs)))+
  ggtitle("pFMP233") +
  xlab("sample") +
  ylab("absolute occupancy / %") +
  geom_point(aes(x = label, y = (100 -(100*avg)), shape = group, color = cat))+
  scale_color_manual(values = new_legend) +
  scale_shape_manual(values = shapes) +
  ylim(c(0,100))+
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(legend.position = "none",
        legend.justification = c(1,0),
        text=element_text(family="Arial Unicode MS"),
        legend.box = "horizontal") +
  guides(
    color = guide_legend(ncol = 1),
    shape = guide_legend(ncol = 1)) +
  labs(caption = "240 min")

ggplot(df %>% dplyr::filter(chr == "genome"))+
  ggtitle("genome") +
  xlab("sample") +
  ylab("absolute occupancy / %") +
  geom_jitter(aes(x = cat, y = (100 -(100*avg)), shape = group, color = cat), height = 0.25)+
  scale_color_manual(values = new_legend) +
  scale_shape_manual(values = shapes) +
  ylim(c(0,100))+
  theme_classic() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  theme(legend.position = c(1,0),
        legend.justification = c(1,0),
        text=element_text(family="Arial Unicode MS"),
        legend.box = "horizontal",
        axis.text.x = element_blank()) +
  guides(
    color = guide_legend(ncol = 1),
    shape = guide_legend(ncol = 1)) +
  labs(color = "",
       shape = "") +
  theme(
    legend.background = element_rect(fill = "transparent", color = NA),
    legend.box.background = element_rect(fill = "transparent", color = NA)
  )
dev.off()

