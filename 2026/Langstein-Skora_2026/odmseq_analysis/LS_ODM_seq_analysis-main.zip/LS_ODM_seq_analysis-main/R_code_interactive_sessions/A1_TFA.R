source(".RProfile")
source("R/plot_fun.R")
library("data.table")

tss <- read.csv(paste0(datasets, "+1coordiantesETC_tirosh_32U.tab"), sep = "\t")

mac <- fread(paste0(datasets, "hits_abf1_Macisaac.bed"),
             sep = "\t", select= c(1:3),
             header = F, col.names = c("chr", "site_start", "site_end")) %>%
  tibble::rowid_to_column("site") %>%
  dplyr::mutate(site = paste0("maci_", site),
                origin = "Macisaac")

pac <-fread(paste0(datasets, "hits_abf1_Pachkov.bed"),
              sep = "\t", select= c(1:3),
              header = F, col.names = c("chr", "site_start", "site_end")) %>%
  tibble::rowid_to_column("site") %>%
  dplyr::mutate(site = paste0("pac_", site),
                origin = "pachkov")

jaspar <- fread(paste0(datasets, "JASPAR_ABF1.tsv"), sep = "\t", select= c(3:5),
                header = T, col.names = c("chr", "site_start", "site_end")) %>%
  tibble::rowid_to_column("site") %>%
  dplyr::mutate(site = paste0("jasp_", site),
                origin = "jaspar")

badis <- fread(paste0(datasets, "badis.tsv"), sep = "\t", select= c(3:5),
                header = T, col.names = c("chr", "site_start", "site_end")) %>%
  tibble::rowid_to_column("site") %>%
  dplyr::mutate(site = paste0("badi_", site),
                origin = "badis")

kubik <- read.csv(paste0(datasets, "centersAbf1Kubik.tab"), sep = " ") %>%
  dplyr::select(chr, start, end) %>%
  dplyr::rename(site_start = start, site_end = end) %>%
  tibble::rowid_to_column("site") %>%
  dplyr::mutate(site = paste0("kubi_", site),
                origin = "kubik")

GSM4449153 <- read.csv(paste0(datasets, "GSM4449153_15254_Abf1_rep1_peaks.bed.gz"), sep = "\t",
                       header = FALSE, col.names = c("chr", "site_start", "site_end", "string", "score"))%>%
  dplyr::mutate(origin = "Pugh-Chip-exo")
GSM4449154 <- read.csv(paste0(datasets, "GSM4449154_19442_Abf1_rep2_peaks.bed.gz"), sep = "\t",
                       header = FALSE, col.names = c("chr", "site_start", "site_end", "string", "score"))%>%
  dplyr::mutate(origin = "Pugh-Chip-exo")

GSM7586203 <- read.csv(paste0(datasets, "Lakshmi_ABF1.csv"), sep = ",") %>%
  dplyr::select(chr, X, A, B, C) %>%
  tidyr::pivot_longer(-c(chr, X), names_to = "rep", values_to = "coord") %>%
  dplyr::group_by(chr, X) %>%
  dplyr::summarise(poi = round(mean(coord, na.rm = T)),
                   site_start = min(coord, na.rm = T),
                   site_end = max(coord, na.rm = T)) %>%
  dplyr::select(-X) %>%
  dplyr::mutate(chr = sub("^([A-Z])", "\\L\\1", chr, perl = TRUE)) %>%
  dplyr::mutate(origin = "Hahn-ChEC")

Zentner <- read.csv(paste0(datasets, "Zentner_Abf1-Table.tsv"), sep = "\t", skip = 2,
                       header = T) %>%
  dplyr::rename(chr = Chromosome, site_start = Peak.start, site_end = Peak.end) %>%
  dplyr::mutate(origin = "Henikoff-ChEC") %>%
  dplyr::select(chr, site_start, site_end, origin)

slim <- read.csv(paste0(datasets, "1_Abf1_positions_SLIM-ChIP.bed"), sep = "\t",
                 header = FALSE, col.names = c("chr", "site_start", "site_end", "string", "score", "unknown")) %>%
  dplyr::mutate(poi = round((site_start + site_end)/2),
                chr = factor(chr)) %>%
  drop_na() %>% unique() %>%
  dplyr::mutate(origin = "SLiM-ChIP") %>%
  dplyr::ungroup() %>%
  dplyr::select(chr, site_start, site_end, origin)

TFBS <- dplyr::bind_rows(GSM4449153, GSM4449154, GSM7586203, Zentner, slim)%>%
  dplyr::select(chr, site_start, site_end, origin)

TFBS %>%
  group_by(origin) %>%
  dplyr::group_map(., ~ write_delim(.x, paste0(external, .y, "_bs.bed"), col_names = F))


bed <- dplyr::bind_rows(TFBS, mac, pac, jaspar, badis, kubik) %>%
  dplyr::mutate(poi = round((site_start + site_end)/2),
                chr = factor(chr)) %>%
  dplyr::select(chr, poi, origin, site_start, site_end) %>%
  drop_na()

bed %>%
  saveRDS(., paste0(external, "abf1_origin_files.rds"))

all_BS <- bed %>%
  dplyr::select(-origin) %>%
  unique() %>%
  dplyr::group_by(chr, poi) %>%
  dplyr::filter(site_end == min(site_end)) %>%
  dplyr::filter(site_start == max(site_start)) %>%
  dplyr::group_by(chr) %>%
  dplyr::arrange(chr, poi) %>%
  dplyr::mutate(difference = poi - dplyr::lag(poi)) %>%
  # only one site within 20 bp is valid (to prevent bias towards a singular locus)
  dplyr::filter(difference > 20) %>%
  dplyr::select(-difference) %>%
  dplyr::ungroup()

write_delim(all_BS, paste0(external, "ABF1_all_sites.bed"), delim = "\t")

