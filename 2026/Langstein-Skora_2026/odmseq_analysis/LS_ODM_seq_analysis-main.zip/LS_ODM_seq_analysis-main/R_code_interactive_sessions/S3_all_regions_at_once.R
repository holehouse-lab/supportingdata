source(".RProfile")
source("R/plot_fun.R")
library("data.table")
library("ggVennDiagram")

essential <- read.csv(paste0(datadir, "YSN_essential.txt"), header = F, col.names = "gene") %>%
  dplyr::pull(gene)

data <- readRDS(paste0(sshfs, snakemake_output, "TFA/Abf1_plus_ones/rds/20240129_corrected.rds"))

# the object 'tidy' contains indo about of gene_id, chr, `+1 nucleosome`, factor i.e. which strand the gene is on; 1 for + and -1 for -
tidy <- readRDS(paste0(datadir, "venn_tidy_all_responders.rds"))

all_v <- list("Flank" = c(-80,0),
              #"NFR" = c(-145, -95),
              "Right" = c(0,50))
filter <- list("essential" = essential,
               "all" = unique(tidy$gene_id),
               "nonessential" = setdiff(unique(tidy$gene_id), essential))

for(j in 1:length(filter)){
  now_filter <- filter[[j]]
  now_names <- names(filter)[[j]]

    insterest <- tidy %>%
      dplyr::select(gene_id, chr, `+1 nucleosome`, factor) %>%
      distinct() %>%
      drop_na()
    
    aligs = tibble()
    for(i in 1:length(all_v)) {
      v <- all_v[[i]]
      v_name <- names(all_v)[[i]]
    genes_to_use <- insterest %>%
      dplyr::filter(gene_id %in% now_filter) %>%
      dplyr::mutate(poi = `+1 nucleosome`,
                    ext_start = poi + v[1],
                    ext_end = poi + v[2])
    
    aligs <- genes_to_use %>%
      dplyr::mutate(pos = purrr::map2(ext_start, ext_end, seq)) %>% 
      unnest(pos) %>%
      select(chr, poi, pos) %>%
      dplyr::mutate(side = v_name) %>%
      dplyr::bind_rows(aligs, .)
    }
    
    
    comps <- dplyr::left_join(aligs, data, by = c("chr", "pos"),relationship = "many-to-many") %>%
      dplyr::mutate(dist = (pos -poi)*factor)
    
    averages <- comps %>%
      dplyr::select(chr, poi, side, sample, avg, dist) %>%
      distinct() %>%
      drop_na() %>%
      dplyr::group_by(chr, poi, side, sample) %>%
      dplyr::summarise(mean = mean(avg, na.rm = T)) %>%
      tidyr::unite("spot",chr, poi, side) %>%
      pivot_wider(names_from = sample, values_from = mean) %>%
      column_to_rownames("spot") %>%
      drop_na() %>%
      t()
    
    pca_result <- prcomp(averages, scale. = F)
    importance <- summary(pca_result) %>%
      magrittr::extract2("importance") %>%
      base::data.frame()
    
    plotting <- pca_result$x %>%
      base::data.frame() %>%
      tibble::rownames_to_column("sample") %>%
      tidyr::separate(sample, into = c("sample","time"), sep = "_") %>%
      dplyr::mutate(cat = dplyr::case_when(
        sample %in% c("ASK460", "ASK461") ~ "negative",
        sample %in% c("ASK459", "ASK455") ~ "positive",
        sample %in% c("ASK454", "ASK458") ~ "mutant",
        sample %in% c("ASK470", "ASK471") ~ "Patchy",
        sample %in% c("ASK468", "ASK469") ~ "ShuffleD",
        sample %in% c("ASKGS1", "ASKGS2") ~ "Control1",
        sample %in% c("ASKFG1", "ASKFG2") ~ "Control2"))
    
    pdf(paste0(plotdir, now_names, "_all_Flank_Right_indiv_pca_of_absolute_occupancy_near_plus_one_result.pdf"), height = 6, width = 8)
    g<- ggplot(plotting, aes(x = PC1, y = PC2, color = cat, shape = time)) +
      scale_shape_manual(values = c(0:14)) +
      scale_color_manual(values =  legend_simple)+
      labs(color = "", shape = "")+
      geom_point(size = 2) +
      theme_classic()+
      xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
      ylab(paste0("PC2: ", round(importance[["PC2"]][2]*100), "%"))
    h<- ggplot(plotting, aes(x = PC1, y = PC3, color = cat, shape = time)) +
      scale_shape_manual(values = c(0:14)) +
      scale_color_manual(values =  legend_simple)+
      labs(color = "", shape = "")+
      geom_point(size = 2) +
      theme_classic()+
      xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
      ylab(paste0("PC3: ", round(importance[["PC3"]][2]*100), "%"))
    f <- ggplot(plotting, aes(x = PC1, y = PC4, color = cat, shape = time)) +
      scale_shape_manual(values = c(0:14)) +
      scale_color_manual(values =  legend_simple)+
      labs(color = "", shape = "")+
      geom_point(size = 2) +
      theme_classic()+
      xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
      ylab(paste0("PC4: ", round(importance[["PC4"]][2]*100), "%"))
    print(g)
    print(h)
    print(f)
    dev.off()
  }
