source(".RProfile")
source("R/plot_fun.R")
library("data.table")

data <- fread(paste0(datasets, "41586_2025_8916_MOESM4_ESM/ref_all-Table 1.tsv"),sep = "\t")

view = 1000

data %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::mutate(poi = poi + ((25)*factor)) %>%
  dplyr::mutate(ext_start = poi - 1,
                ext_end = poi + 1) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  drop_na(poi) %>%
  saveRDS(., paste0(external, "Hahn_plus_25_one_data.table.rds"))

data %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::mutate(poi = poi + ((-120)*factor)) %>%
  dplyr::mutate(ext_start = poi - 1,
                ext_end = poi + 1) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  drop_na(poi) %>%
  saveRDS(., paste0(external, "Hahn_minus_120_one_data.table.rds"))

data %>%
  dplyr::rename(poi = `+1 nucleosome`) %>%
  dplyr::select(chr, poi, strand) %>%
  dplyr::mutate(factor = dplyr::case_when(
                  strand == "W" ~ 1,
                  strand == "C" ~ -1)) %>%
  dplyr::mutate(poi = poi + ((-40)*factor)) %>%
  dplyr::mutate(ext_start = poi - 1,
                ext_end = poi + 1) %>%
  dplyr::select(chr, ext_start, ext_end, poi, factor) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end) %>%
  drop_na(poi) %>%
  saveRDS(., paste0(external, "Hahn_minus_40_one_data.table.rds"))




