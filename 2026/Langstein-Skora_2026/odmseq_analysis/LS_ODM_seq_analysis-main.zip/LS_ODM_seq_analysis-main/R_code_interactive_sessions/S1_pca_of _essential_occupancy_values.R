source(".RProfile")
source("R/plot_fun.R")
library("data.table")
library("ggVennDiagram")

essential <- read.csv(paste0(datadir, "YSN_essential.txt"), header = F, col.names = "gene") %>%
  dplyr::pull(gene)
data <- readRDS(paste0(sshfs, snakemake_output, "TFA/Abf1_plus_ones/rds/20240129_corrected.rds"))
# the object 'tidy' contains indo about of gene_id, chr, `+1 nucleosome`, factor i.e. which strand the gene is on; 1 for + and -1 for -
tidy <- readRDS(paste0(datadir, "venn_tidy_all_responders.rds"))

all_v <- list(c(-80,0),
              c(-145, -95),
              c(-40, 0),
              c(0,50))
filter <- list("essential" = essential,
               "all" = unique(tidy$gene_id),
               "nonessential" = setdiff(unique(tidy$gene_id), essential))

for(i in 1:length(all_v)) {
  v <- all_v[[i]]
  for(j in 1:length(filter)){
    now_filter <- filter[[j]]
    now_names <- names(filter)[[j]]

insterest <- tidy %>%
  dplyr::select(gene_id, chr, `+1 nucleosome`, factor) %>%
  distinct() %>%
  drop_na()

genes_to_use <- insterest %>%
  dplyr::filter(gene_id %in% now_filter) %>%
  dplyr::mutate(poi = `+1 nucleosome`,
                ext_start = poi + v[1],
                ext_end = poi + v[2])

aligs <- genes_to_use %>%
  dplyr::mutate(pos = purrr::map2(ext_start, ext_end, seq)) %>% 
  unnest(pos) %>%
  select(chr, poi, pos)

comps <- dplyr::left_join(aligs, data, by = c("chr", "pos"),relationship = "many-to-many") %>%
  dplyr::mutate(dist = (pos -poi)*factor) %>%
  dplyr::mutate(side = sign(dist))

averages <- comps %>%
  dplyr::select(chr, poi, side, sample, cat, avg, dist) %>%
  distinct() %>%
  drop_na() %>%
  tidyr::separate(sample, into = c("sample", "time")) %>%
  dplyr::group_by(chr, poi, side, sample, time, cat) %>%
  dplyr::summarise(mean = mean(avg, na.rm = T)) %>%
  dplyr::group_by(chr, poi, side, sample, cat) %>%
  dplyr::summarise(mean = mean(mean, na.rm = T))%>%
  dplyr::group_by(chr, poi, side, cat) %>%
  dplyr::summarise(mean = mean(mean, na.rm = T)) %>%
  tidyr::unite("spot",chr, poi, side) %>%
  pivot_wider(names_from = cat, values_from = mean) %>%
  column_to_rownames("spot") %>%
  drop_na() %>%
  t()

pca_result <- prcomp(averages, scale. = F)
importance <- summary(pca_result) %>%
  magrittr::extract2("importance") %>%
  base::data.frame()

plotting <- pca_result$x %>%
  base::data.frame() %>%
  tibble::rownames_to_column("cat")

pdf(paste0(plotdir, now_names, "_", v[1], "_", v[2],"_pca_of_absolute_occupancy_near_plus_one_result.pdf"), height = 6, width = 8)
a <- ggplot(plotting, aes(x = PC1, y = PC2, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC2: ", round(importance[["PC2"]][2]*100), "%"))
b <-ggplot(plotting, aes(x = PC1, y = PC3, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC3: ", round(importance[["PC3"]][2]*100), "%"))
c <- ggplot(plotting, aes(x = PC1, y = PC4, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC4: ", round(importance[["PC4"]][2]*100), "%"))
print(a)
print(b)
print(c)
dev.off()

wt <- averages %>%
  t() %>%
  as.data.frame() %>%
  mutate(across(-positive, ~ . - positive)) %>%
  select(-positive) %>%
  t()

pca_result <- prcomp(wt, scale. = F)
importance <- summary(pca_result) %>%
  magrittr::extract2("importance") %>%
  base::data.frame()

plotting <- pca_result$x %>%
  base::data.frame() %>%
  tibble::rownames_to_column("cat")

pdf(paste0(plotdir, now_names, "_", v[1], "_", v[2], "_pca_of_differences_near_plus_one_result.pdf"), height = 6, width = 8)
d <- ggplot(plotting, aes(x = PC1, y = PC2, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC2: ", round(importance[["PC2"]][2]*100), "%"))
e <- ggplot(plotting, aes(x = PC1, y = PC3, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC3: ", round(importance[["PC3"]][2]*100), "%"))
f <- ggplot(plotting, aes(x = PC1, y = PC4, color = cat)) +
  scale_shape_manual(values = c(0:14)) +
  scale_color_manual(values =  legend_simple)+
  labs(color = "", shape = "")+
  geom_point(size = 2) +
  theme_classic()+
  xlab(paste0("PC1: ", round(importance[["PC1"]][2]*100), "%"))+
  ylab(paste0("PC4: ", round(importance[["PC4"]][2]*100), "%"))
print(d)
print(e)
print(f)
dev.off()
  }
}
