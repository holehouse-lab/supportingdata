source(".RProfile")
source("R/plot_fun.R")
library("data.table")
library("ggVennDiagram")

tb <- readRDS(paste0(sshfs, snakemake_TFA, "/Abf1_asym/Hahn_resp/20240129_Hahn_resp_umap_fixed.rds"))

tb %>%
  dplyr::select(chr, poi, occ, sample, cat, dist) %>%
  write_delim(., outpath, delim = "\t")

abs_count <- tb %>% dplyr::select(chr, poi, sample, cat) %>%
  dplyr::distinct() %>%
  dplyr::group_by(sample, cat) %>%
  dplyr::summarise(count = n()) %>%
  dplyr::pull(count) %>%
  max()

plotting <- tb %>%
  dplyr::select(cat, dist, avg) %>%
  dplyr::group_by(cat, dist) %>%
  dplyr::summarize(mean_occ = mean((1-avg), na.rm = T)) %>%
  dplyr::group_by(cat) %>%
  dplyr::arrange(cat, dist) %>%
  dplyr::mutate(focc = data.table::frollmean(mean_occ, n = 50, align = "center", na.rm = T))

pdf(paste0(plotdir, "Explanation_plot.pdf"), height = 4, width = 8)
ggplot(plotting %>% dplyr::filter(cat %in% c("positive", "negative"))) +
  theme_classic() +
  scale_color_manual(values = legend_simple) +
  geom_line(aes(x = dist, y = focc *100, color = cat)) +
  ylim(c(0,100))+
  scale_x_continuous(
    breaks = c(-500, -375, -250, -125, 0, 125, 250, 375, 500),
    labels = c("-500", "", "-250", "", "0", "", "250", "", "500"),
    limits = c(-500, 500)) +
  geom_vline(xintercept = 0, color = "gray30", linetype = "dashed") +
  
  geom_segment(aes(x = -145,  xend = -95, y = 50, yend = 50)) +
  geom_text(aes(x = -120, y = 50), label = "50 bp", vjust = -0.2, size = 4) +
  
  geom_segment(aes(x = -80,  xend = -0, y = 40, yend = 40)) +
  geom_text(aes(x = -40, y = 40), label = "80 bp", vjust = -0.2, size = 4) +
  
  geom_segment(aes(x = 0,  xend = 50, y = 90, yend = 90)) +
  geom_text(aes(x = 25, y = 90), label = "50 bp", vjust = -0.2, size = 4) +
  theme(legend.position = "none") +
  ylab("absolute occupancy (smoothed n = 50)") +
  xlab("distance to +1 nucleosome / bp") +
  labs(caption = paste0("number of genes: ", abs_count))+
  ggtitle("Hahn_resp")
dev.off()









