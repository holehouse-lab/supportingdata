source(".RProfile")
library("data.table")

prep = "Abf1_plus_ones"
id = "20240129"
fixed_poi = "fixed_plus_one"

if(fixed_poi == "fixed_plus_one"){
  xlab = "distance to +1 nuclesome / bp"
}else{
  xlab = "distance to alignment point / bp"
}

data <- readRDS(paste0(sshfs, snakemake_TFA, prep, "/", fixed_poi,"/", id, "_",fixed_poi , "_aligned_fixed.rds"))

levs = c("no Abf1", "Local Shuffle 12", "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045", "altered aromatic patterning", "Gal4 shuffle", "Fus Gal4 motif", "WT Abf1")

labelled <- data %>%
  dplyr::rename(barcode = sample) %>%
  tidyr::separate(barcode, into = c("sample", "time"), sep = "_", remove = F) %>%
  dplyr::mutate(cat = dplyr::case_when(
    sample %in% c("ASK460", "ASK461") ~ "no Abf1",
    sample %in% c("ASK459", "ASK455") ~ "WT Abf1",
    sample %in% c("ASK454", "ASK458") ~ "FUS\U00B9\U207B\U00B9\U2076\U00B3\U0031\U0032\U0045",
    sample %in% c("ASK470", "ASK471") ~ "altered aromatic patterning",
    sample %in% c("ASK468", "ASK469") ~ "Local Shuffle 12",
    sample %in% c("ASKGS1", "ASKGS2") ~ "Gal4 shuffle",
    sample %in% c("ASKFG1", "ASKFG2") ~ "Fus Gal4 motif")) %>%
  dplyr::mutate(rep = dplyr::case_when(
    sample %in% c("ASK460", "ASK459", "ASK454", "ASK470", "ASK468", "ASKGS1", "ASKFG1") ~ "replicate 1",
    sample %in% c("ASK461", "ASK455", "ASK458", "ASK471", "ASK469", "ASKGS2", "ASKFG2") ~ "replicate 2")) %>%
  dplyr::mutate(cat = factor(cat, levels = levs))
  
plotting <- labelled %>%
  dplyr::group_by(dist, cat) %>%
  dplyr::summarise(mean_occ = mean(mean_occ)) %>%
  dplyr::group_by(cat) %>%
  dplyr::arrange(dist) %>%
  dplyr::mutate(focc = data.table::frollmean(mean_occ, n = 50, align = "center"))

plotting2 <- labelled %>%
  dplyr::group_by(barcode) %>%
  dplyr::arrange(dist) %>%
  dplyr::mutate(focc = data.table::frollmean(mean_occ, n = 50, align = "center"))

pdf(paste0(plotdir, "abf1_", fixed_poi, "_grid.pdf"), height = 6, width = 8)
ggplot(plotting2 %>%
         dplyr::filter(time == "240"))+
  geom_line(aes(x = dist, y = focc, linetype = rep, color = cat)) +
  scale_color_manual(values = new_legend)+
  scale_linetype_manual(values = c("replicate 1" = "dashed",
                                   "replicate 2" = "dotted",
                                   "replicate 3" = "longdash")) +
  ylim(c(0,1))+
  theme_classic()+
  theme(strip.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  ylab("absolute occupancy / %") +
  xlab(xlab)+
  ggtitle("") +
  labs(linetype = "240 min") +
  scale_x_continuous(
    breaks = c(-500, -375, -250, -125, 0, 125, 250, 375, 500),
    labels = c("-500", "", "-250", "", "0", "", "250", "", "500"),
    limits = c(-500, 500))+
  facet_wrap(~ cat)+
  theme(text=element_text(family="Arial Unicode MS")) +
  guides(colour = "none") +
  theme(legend.position = c(0.98,0.02),
        legend.justification = c(1,0))
dev.off()

pdf(paste0(plotdir, "abf1_", fixed_poi, "_grid_by_rep.pdf"), height = 12, width = 8)
ggplot(plotting2) +
  geom_line(aes(x = dist, y = focc, linetype = time, color = cat)) +
  scale_color_manual(values = new_legend)+
  scale_linetype_manual(values = c("180" = "dashed",
                                   "240" = "dotted")) +
  ylim(c(0,1))+
  theme_classic() +
  ylab("absolute occupancy / %") +
  xlab(xlab)+
  ggtitle("") +
  theme_classic()+
  theme(strip.background = element_blank(),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  scale_x_continuous(
    breaks = c(-500, -375, -250, -125, 0, 125, 250, 375, 500),
    labels = c("-500", "", "-250", "", "0", "", "250", "", "500"),
    limits = c(-500, 500))+
  facet_grid(cat ~ rep)+
  theme(text=element_text(family="Arial Unicode MS")) +
  guides(colour = "none") +
  theme(legend.position = "none")
dev.off()
