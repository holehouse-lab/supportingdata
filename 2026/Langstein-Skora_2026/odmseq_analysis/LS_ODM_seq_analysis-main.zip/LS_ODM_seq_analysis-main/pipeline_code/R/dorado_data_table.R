source("R/.RProfile")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

input = args[1]
output_table = args[2]
output = args[3]
sample = args[4]
cat = args[5]
v = args[6] %>% as.character()

data <- read.csv(input, header = F, sep = "\t", col.names = c("chrm", "start", "end", "modbase", "score", "strand", "ab1", "ab2", "ab3", "cov", "percentage", "Nmod", "Ncanonical", "Nother_mod", "Ndelete", "Nfail", "Ndiff", "Nnocall")) %>%
  dplyr::select(chrm, start, strand, modbase, score, cov, percentage)

table <- data %>%
  dplyr::filter(modbase %in% v) %>%
  dplyr::rename(chr = chrm, pos = start) %>%
  dplyr::mutate(occ = 1 - percentage/100,
                avg = percentage/100) %>%
  dplyr::filter(cov >= 1)

write_delim(table, output_table, delim = "\t")

df <- table %>%
  dplyr::mutate(end = pos + 1) %>%
  data.table() %>%
  data.table::setkey(., chr, pos, end)  %>%
  drop_na() %>%
  dplyr::mutate(sample = sample,
                cat = cat)

saveRDS(df, output)