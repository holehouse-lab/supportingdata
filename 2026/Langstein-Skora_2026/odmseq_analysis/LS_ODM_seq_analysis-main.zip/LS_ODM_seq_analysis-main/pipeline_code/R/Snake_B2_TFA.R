source("R/.RProfile")
source("R/src_TFA.R")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

input = args[1]
input2 = args[2]
outdir = args[3]
poi_ = args[4]
offset = args[5] %>% as.numeric()
delta = args[6] %>% as.numeric()
runid = args[7]

bed <- readRDS(input)
cats <- readRDS(input2)

print(bed)
print(cats)

plotting <- bed %>%
  dplyr::mutate(motif = paste0(chr, "_", site_start, "_", site_end)) %>%
  dplyr::left_join(cats, ., by = "motif") %>%
  dplyr::mutate(offset = as.character(offset),
                delta = as.character(delta)) %>%
  dplyr::mutate(allfactor = dplyr::case_when(
    is.nan(strandfactor) ~ 1,
    !is.nan(strandfactor) ~ strandfactor)) %>%
  dplyr::mutate(subcat2 = subcat)

saveRDS(plotting, paste0(outdir, runid, "_", poi_, "_offset_", as.character(offset), "_delta_",  as.character(delta), ".significant_motifs_and_factors.rds"))

general_subsets <- plotting %>%
  split(., .$subcat2) %>%
  purrr::map(.,  ~data.tablify(.x, motif_col = "motif", factor_col = "pfactor", "offset", "delta", "subcat"))

walk2(names(general_subsets), general_subsets,
      ~saveRDS(.y,
               paste0(outdir, runid, "_", poi_, "_offset_", as.character(offset), "_delta_",  as.character(delta),".", .x, "_all_data.table.rds")))

canon_tss <- plotting %>%
  dplyr::filter(factor != 0) %>%
  split(., .$subcat2) %>%
  purrr::map(.,  ~data.tablify(.x, motif_col = "motif", factor_col = "pfactor", "offset", "delta", "subcat"))

walk2(names(canon_tss), canon_tss,
      ~saveRDS(.y,
               paste0(outdir, runid, "_", poi_, "_offset_", as.character(offset), "_delta_",  as.character(delta), ".", .x, "_canonical_tss_data.table.rds")))

no_tss <- plotting %>%
  dplyr::filter(notss_factor != 0) %>%
  split(., .$subcat2) %>%
  purrr::map(.,  ~data.tablify(.x, motif_col = "motif", factor_col = "pfactor", "offset", "delta", "subcat"))

walk2(names(no_tss), no_tss,
      ~saveRDS(.y,
               paste0(outdir, runid, "_" ,poi_, "_offset_", as.character(offset), "_delta_",  as.character(delta), ".", .x, "_no_tss_data.table.rds")))

