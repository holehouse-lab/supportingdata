source("R/.RProfile")

args <- commandArgs(trailingOnly = TRUE)

# These lower and upper limits ensure that sequence shared between vectors used
# for multiple spike-ins is not misattributed.
# Only values of unique regions will be included.
lpFTZ = 251
upFTZ = 3357
name_FTZ = "puc19_ftz"

lpFMP = 432
upFMP = 5360
name_FMP = "pFMP233"

input = args[1]
output_joined = args[2]
barcode = args[3]
cat = args[4]

data <- readRDS(input)

print(as_tibble(data))

pFTZ <- data %>%
  dplyr::filter(chr == name_FTZ & pos %in% lpFTZ:upFTZ) %>%
  dplyr::group_by(chr) %>%
  dplyr::summarise(avg = mean(avg),
		   count = mean(cov)) %>%
  as_tibble()

pFMP <- data %>%
  dplyr::filter(chr == name_FMP & pos %in% lpFMP:upFMP) %>%
  dplyr::group_by(chr) %>%
  dplyr::summarise(avg = mean(avg),
                   count = mean(cov)) %>%
  as_tibble()

average <- data %>%
  dplyr::filter(chr != name_FMP & chr != name_FTZ) %>%
  dplyr::group_by(chr) %>%
  dplyr::summarise(avg = mean(avg),
                   count = mean(cov))%>%
  as_tibble()

genome <- data %>%
  dplyr::summarise(avg = mean(avg),
                   count = mean(cov)) %>%
  dplyr::mutate(chr = "genome") %>%
  as_tibble()

full <- dplyr::bind_rows(average, genome) %>%
  dplyr::bind_rows(., pFMP) %>%
  dplyr::bind_rows(., pFTZ)

joined <- full %>%
  dplyr::mutate(sample = barcode)%>%
  dplyr::mutate(cat = cat)

saveRDS(joined, output_joined)
