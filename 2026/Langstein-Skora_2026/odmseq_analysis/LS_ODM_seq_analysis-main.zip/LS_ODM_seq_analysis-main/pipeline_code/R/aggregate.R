source("R/.RProfile")

args <- commandArgs(trailingOnly = TRUE)

group_output = args[1]
input = args[-1]

file <- tibble()
for(i in 1:length(input)){
  rds <- input[[i]]
  if (file.exists(rds) && file.info(rds)$size > 0) {
    data <- readRDS(rds)
    file <- file %>%
      dplyr::bind_rows(., data)
  }
}
saveRDS(file, group_output)
