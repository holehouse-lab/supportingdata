source("R/.RProfile")
source("R/src_TFA.R")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

input = args[1]
pmw_rds = args[2]
poi_ = args[3]
offset = args[4] %>% as.numeric()
delta = args[5] %>% as.numeric()
output = args[6]
output2 = args[7]
test_against = args[8]
table = args[9]

bed <- readRDS(pmw_rds)

tibble <- readRDS(input)

print(tibble)

tibble <- tibble %>% drop_na()
    
category_table <- read.csv(table, sep = "\t", header = T) %>%
  dplyr::rename(sample = SampleName, cat = Category) %>%
  dplyr::select(-SamplePath)
    
left <- bed %>%
  dplyr::mutate(ext_start = (poi - offset - delta),
                ext_end = (poi - offset + delta)) %>%
  dplyr::mutate(side = "left")
    
right <- bed %>%
  dplyr::mutate(ext_start = (poi + offset - delta),
                ext_end = (poi + offset + delta)) %>%
  dplyr::mutate(side = "right")
    
double_bed <- dplyr::bind_rows(left, right) %>%
  data.table() %>%
  data.table::setkey(., chr, ext_start, ext_end)
    
print(double_bed)

  foverlap <- data.table::foverlaps(x = tibble,
                                    y = double_bed,
                                    by.y = c("chr", "ext_start", "ext_end"),
                                    by.x = c("chr", "pos", "end"))
print(foverlap)

full_length <- foverlap %>%
  dplyr::filter(!is.na(poi)) %>%
  dplyr::mutate(pos = dplyr::case_when(
        strand == "+" ~ pos,
        strand == "-" ~ pos -1)) %>%
  dplyr::mutate(motif = paste0(chr, "_", site_start, "_", site_end, "_", side))
    
averaged <- full_length %>%
  dplyr::filter(cov >= 10) %>%
  dplyr::group_by(sample, cat, chr, pos) %>%
  dplyr::mutate(avg = mean(avg)) %>%
  dplyr::group_by(motif, sample, cat) %>%
  dplyr::summarize(avg = mean(avg),
                   cov = mean(cov)) %>%
  dplyr::filter(cov >= 10) %>%
  dplyr::select(-cov)
    
purrrlist <- averaged %>%
  dplyr::ungroup() %>%
  split(.$motif) %>%
  purrr::map(~ select(.x, cat, avg)) %>%
  purrr::map(~ split(x = .x, .$cat)) %>%
  purrr::map(~ purrr::map(.x, ~ pull(.x, avg)))
    
against = test_against
allcat <- tibble$cat %>%
  unique() %>%
  magrittr::extract(. != against)
    
pname <- paste0("p_", allcat)
dname <- paste0("d_", allcat)
    
list <- list()
for(i in 1:length(allcat)){
  list[[i]] <- purrr_compare_groups(purrrlist,
                                    group1 = against,
                                    group2 = allcat[i],
                                    names = "motif",
                                    pval = pname[i],
                                    mval = dname[i])
}
    
summarized <- reduce(list, left_join, by = "motif")
    
cats <- map_df(allcat, ~find_most_and_least(data = summarized, category = .x)) %>%
  tidyr::separate(motif, into = c("motif", "side"), 
                  sep = "_(?=[^_]+$)", remove = TRUE, convert = FALSE) %>%
  dplyr::group_by(motif) %>%
  pivot_longer(
    cols = starts_with("p_") | starts_with("d_"),
    names_to = c(".value", "sample"),
    names_sep = "_") %>%
  dplyr::filter(str_detect(subcat, pattern = sample)) %>%
  dplyr::group_by(motif, subcat) %>%
  dplyr::filter(p == min(p)) %>%
  dplyr::mutate(pfactor = dplyr::case_when(
    side == "left" ~ -1,
    side == "right" ~ 1)) %>%
  dplyr::group_by(motif, subcat, sample) %>%
  dplyr::filter(pfactor == max(pfactor)) %>%
  dplyr::ungroup()

saveRDS(cats, output2)
    
motifs <- cats %>%
  dplyr::select(motif, subcat)
    
write_delim(motifs,output,delim = "\t")
