source("R/.RProfile")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

data_table_path = args[1]
subset_methylation_path = args[2]
output_path = args[3]
test_against = as.character(args[4])
bool = as.logical(args[5])

subset_methylation <- readRDS(subset_methylation_path)
data_table <- readRDS(data_table_path)

if(bool == TRUE){
  print("subset methylation")
  print(subset_methylation)
  
  avgs <- subset_methylation %>%
    dplyr::filter(chr =="genome") %>%
    dplyr::group_by(cat) %>%
    dplyr::summarize(mean = mean(avg))
  
  print("avgs")
  print(avgs)
  
  value <- avgs %>%
    dplyr::filter(cat == test_against) %>%
    dplyr::pull(., mean)
  
  print("value")
  print(value)
  
  if(length(value) > 1){
    base::stop(paste0("category: ", test_against, " yields multiple rows after summarize"))
  }
  
  factorized = avgs %>%
    dplyr::mutate(factor = mean/value)
  
  merged <- dplyr::full_join(data_table, factorized, by = "cat") %>%
    dplyr::mutate(avg = avg/factor,
                  end = pos + 1,
                  occ = 1-avg) %>%
    data.table() %>%
    data.table::setkey(., chr, pos, end)
  
  print("merged")
  print(merged)
  
} else {
  merged <- data_table %>%
    data.table() %>%
    data.table::setkey(., chr, pos, end)
  print("no correction conducted")
}

saveRDS(merged, output_path)
