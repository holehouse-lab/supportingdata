source("R/.RProfile")
source("R/src_TFA.R")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

test_against <- args[1]
outpath <- args[2]
composites_path <- args[3]
subset_methylation_path <- args[4]
all_binding_site_counts <- args[-(1:4)]

bs_counts <- tibble()
for(i in 1:length(all_binding_site_counts)){
  path = all_binding_site_counts[[i]]
  if (file.exists(path) && file.info(path)$size > 0) {
  data <- read.csv(path, sep = "\t")
  bs_counts <- dplyr::bind_rows(bs_counts, data)}}

print(bs_counts)
print("bs_counts")

if (file.exists(composites_path) && file.info(composites_path)$size > 0 && file.exists(subset_methylation_path) && file.info(subset_methylation_path)$size > 0) {
composites <- readRDS(composites_path)
subset_methylation <- readRDS(subset_methylation_path)

labels <- subset_methylation %>%
  dplyr::select(sample, cat) %>%
  distinct()

avgs <- subset_methylation %>%
  dplyr::filter(chr =="genome") %>%
  dplyr::group_by(cat) %>%
  dplyr::summarize(mean = 1-mean(avg))

value <- avgs %>%
  dplyr::filter(cat == test_against) %>%
  dplyr::pull(., mean)

if(length(value) > 1){
  base::stop(paste0("category: ", test_against, " yields multiple rows after summarize"))
}

factorized = avgs %>%
  dplyr::mutate(factor = mean/value)

print("factorized")
print(factorized)
print("composites")
print(composites)
merged <- composites %>%
  dplyr::left_join(., labels, by = "sample") %>%
  dplyr::left_join(., factorized, by = "cat") %>%
  dplyr::mutate(avg = avg_meth*factor)%>%
  tidyr::separate(sample, into = c("sample", "time"), sep = "_") %>%
  data.table() %>%
  tidyr::unite("category", c(offset, delta, subcat, specifier), sep = "_", remove = T)

print("merged")
print(merged)
print("bs_counts")
print(bs_counts)

plotting <- merged %>%
  dplyr::left_join(., bs_counts, by = "category", relationship = "many-to-many") %>%
  dplyr::mutate(category = paste0(count.y, "_", category)) %>%
  dplyr::group_by(cat, category, dist) %>%
  dplyr::mutate(mean_occ = mean_occ/factor) %>% # avg*factor
  dplyr::summarise(mean = mean(mean_occ)) %>%
  dplyr::group_by(cat, category) %>%
  dplyr::arrange(cat, category, dist) %>%
  dplyr::mutate(mean_occ = data.table::frollmean(mean, n = 50, align = "center")*100)

saveRDS(plotting, outpath)
}else{
print("Waringing: Output not generated because subroup files are empty!")}
