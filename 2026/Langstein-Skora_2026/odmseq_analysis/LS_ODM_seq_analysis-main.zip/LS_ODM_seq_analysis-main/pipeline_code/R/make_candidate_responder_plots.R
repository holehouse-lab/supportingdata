source("R/.RProfile")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

inpath = args[1]
outpath = args[2]
plot_path = args[3]
alignment_set = as.character(args[4])

tb <- readRDS(inpath)
  
  tb %>%
    dplyr::select(chr, poi, occ, sample, cat, dist) %>%
    write_delim(., outpath, delim = "\t")
  
  abs_count <- tb %>% dplyr::select(chr, poi, sample, cat) %>%
    dplyr::distinct() %>%
    dplyr::group_by(sample, cat) %>%
    dplyr::summarise(count = n()) %>%
    dplyr::pull(count) %>%
    max()
  
  plotting <- tb %>%
    dplyr::select(cat, dist, avg) %>%
    dplyr::group_by(cat, dist) %>%
    dplyr::summarize(mean_occ = mean((1-avg), na.rm = T)) %>%
    dplyr::group_by(cat) %>%
    dplyr::arrange(cat, dist) %>%
    dplyr::mutate(focc = data.table::frollmean(mean_occ, n = 50, align = "center", na.rm = T))
  
  pdf(plot_path, height = 4, width = 8)
  ggplot(plotting) +
    theme_classic() +
    scale_color_manual(values = legend_simple) +
    geom_line(aes(x = dist, y = focc *100, color = cat)) +
    ylim(c(0,100))+
    scale_x_continuous(
      breaks = c(-500, -375, -250, -125, 0, 125, 250, 375, 500),
      labels = c("-500", "", "-250", "", "0", "", "250", "", "500"),
      limits = c(-500, 500)) +
    theme(legend.position = "none") +
    ylab("absolute occupancy (smoothed n = 50)") +
    xlab("distance / bp") +
    labs(caption = paste0("number of sites: ", abs_count))+
    ggtitle(alignment_set)
  dev.off()  
