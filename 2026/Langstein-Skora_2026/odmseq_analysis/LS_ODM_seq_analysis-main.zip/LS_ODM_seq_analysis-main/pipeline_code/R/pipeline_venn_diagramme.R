source("R/.RProfile")
source("R/src_TFA.R")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

outname = args[2]
outtable = args[1]
context = args[3]
samples = args[-(1:3)]

tibble <- tibble()
for(i in 1:length(samples)){
  path = samples[[i]]
  if (file.exists(path) && file.info(path)$size > 0) {
    data <- readRDS(path)
    tibble <- dplyr::bind_rows(tibble, data)
  }
}

print(tibble)

nbs <- tibble %>%
  dplyr::mutate(context = context) %>%
  tidyr::unite("category", c(offset, delta, subcat, context), sep = "_", remove = T) %>%
  dplyr::group_by(category) %>%
  dplyr::summarise(count = n())

write_delim(nbs, outtable, delim = "\t")
saveRDS(tibble, outname)
