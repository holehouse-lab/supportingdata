source("R/.RProfile")
library("data.table")

args <- commandArgs(trailingOnly = TRUE)

input = args[1]
print(input)
params_table = args[2]
print(params_table)
output_rds = args[3]
print(output_rds)
# Add as columns to rds
delta = args[4]
print(delta)
offset = args[5]
print(offset)
subcat = args[6]
print(subcat)
specifier = args[7]
print(specifier)
umap_rds = args[8]
print(umap_rds)

#LOAD DATA_SETS
if (file.exists(input) && file.info(input)$size > 0 && file.exists(params_table) && file.info(params_table)$size > 0) {
aligment <- readRDS(params_table) %>%
  dplyr::arrange(chr, poi)
print(aligment)
mod <- readRDS(input) %>%
  dplyr::arrange(chr, pos) %>%
  data.table() %>%
  data.table::setkey(chr,  pos, end)
print(mod)

foverlap1 <- data.table::foverlaps(x = mod,
                                   y = aligment,
                                   by.y = c("chr", "ext_start", "ext_end"),
                                   by.x = c("chr", "pos", "end")) %>%
  tidyr::drop_na()

foverlap2 <- foverlap1 %>%
  dplyr::mutate(dist = (pos - poi)*factor)

foverlap2 %>%
  dplyr::mutate(offset = offset,
                delta = delta,
                subcat = subcat,
                specifier = specifier) %>%
                saveRDS(., umap_rds)

foverlap3 <- foverlap2 %>%
  dplyr::group_by(sample, dist) %>%
  dplyr::summarise(avg_meth = mean(avg),
                   mean_occ = mean(occ),
                   count = n())

tosave <- foverlap3 %>%
  dplyr::mutate(offset = offset,
                delta = delta,
                subcat = subcat,
                specifier = specifier)
saveRDS(tosave, output_rds)
}else{
print("Warning: Input file was empty, Snakemake will create dummy output file!")}
