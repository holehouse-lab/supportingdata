library("data.table")

purrr_compare_groups <- function(list, group1, group2, names, pval, mval){
  pvector <- list %>%
    purrr::map(~ if (is.null(.x[[group1]]) | is.null(.x[[group2]]) | 
                     length(.x[[group1]]) <2 | length(.x[[group2]]) <2) {
      list(p.value = NaN)
    } else {
      t.test(.x[[group1]], .x[[group2]])
    }) %>%
    map_dbl(~.x$p.value)
  
  pval_gr2 <- tibble(!!names := names(pvector), !!pval := pvector)
  
  meanvector <- list %>%
    map(~ if (is.null(.x[[group1]]) | is.null(.x[[group2]]) | 
              length(.x[[group1]]) < 2 | length(.x[[group2]]) < 2) {
      list(mean_diff = NaN)
    } else {
      list(mean_diff = mean(.x[[group1]]) - mean(.x[[group2]]))
    }) %>%
    map_dbl(~.x$mean_diff)
  
  mean_gr2 <- tibble(!!names := names(meanvector), !!mval := meanvector)
  
  sign_group2 <- dplyr::full_join(pval_gr2, mean_gr2, by = names)
  return(sign_group2)
}


find_most_and_least <- function(data, category, most_val = "more", least_val = "less") {
  p_col <- paste0("p_", category)
  delta_col <- paste0("d_", category) 
  
  most <- data %>%
    dplyr::filter(!!sym(p_col) < 0.01 & !!sym(delta_col) > 0) %>%
    mutate(subcat = paste(most_val, category, sep = "_"))
  
  least <- data %>%
    dplyr::filter(!!sym(p_col) < 0.01 & !!sym(delta_col) < 0) %>%
    mutate(subcat = paste(least_val, category, sep = "_"))
    
  return <- bind_rows(most, least)
  return(return)
}

data.tablify <- function(data, motif_col, factor_col, offset, delta, subcat){
  return <- data %>%
    dplyr::ungroup() %>%
    dplyr::select({{motif_col}}, {{factor_col}}, {{offset}}, {{delta}}, {{subcat}}) %>%
    tidyr::separate({{motif_col}}, sep = "_", into = c("chr", "start", "end")) %>%
    dplyr::mutate(start = as.numeric(start),
                  end = as.numeric(end),
                  factor = as.numeric(!!sym(factor_col)),
                  poi = round((start + end)/2),
                  ext_start = poi -1000,
                  ext_end = poi + 1000) %>%
    dplyr::select(chr, ext_start, ext_end, poi, factor, {{offset}}, {{delta}}, {{subcat}}) %>%
    data.table() %>%
    data.table::setkey("chr", "ext_start", "ext_end")
  return(return)
}

tidyvenn <- function(data, name = ""){
  plotting <- data %>%
    dplyr::select(motif, from) %>%
    split(., .$from) %>%
    purrr::map(~ pull(.x, motif))
  
  g <- venn::venn(plotting, zcolor = "style", opacity = 0.1, cexil= 1, ggplot = T, ilabels = "counts") +
    ggplot2::annotate("text", x = 160, y = 960, label = name, size = 5)
  return(g)
}


  
